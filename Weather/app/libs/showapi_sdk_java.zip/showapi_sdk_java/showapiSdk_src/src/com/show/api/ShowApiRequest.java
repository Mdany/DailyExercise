package com.show.api;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.show.api.util.ShowApiLogger;
import com.show.api.util.ShowApiUtils;
import com.show.api.util.WebUtils;


/**
 * 基于REST的客户端。
 */
public class ShowApiRequest extends NormalRequest  {
	private String appSecret;
	 
	public ShowApiRequest(String url,String appid,String appSecret    ) {
		super(url);
		this.appSecret = appSecret;
		this.textMap.put("showapi_appid",appid);
	}
	

	public String getAppSecret() {
		return appSecret;
	}
	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}
	
	private String addSign() throws IOException{
		if(textMap.get(Constants.SHOWAPI_APPID)==null)return errorMsg(Constants.SHOWAPI_APPID+"不得为空!");
		if(textMap.get(Constants.SHOWAPI_SIGN_METHOD)==null)textMap.put(Constants.SHOWAPI_SIGN_METHOD,"md5");
		if(!textMap.get(Constants.SHOWAPI_SIGN_METHOD).equals("md5")
				&&!textMap.get(Constants.SHOWAPI_SIGN_METHOD).equals("hmac"))return errorMsg("showapi_sign_method参数只能是md5或hmac");
		SimpleDateFormat df=new SimpleDateFormat(Constants.DATE_TIME_FORMAT);
		String timestamp= df.format(new Date());
		textMap.put(Constants.SHOWAPI_TIMESTAMP,timestamp);
		String signMethod=textMap.get(Constants.SHOWAPI_SIGN_METHOD)+"";
		if (Constants.SIGN_METHOD_MD5.equals(signMethod)) {
			textMap.put(Constants.SHOWAPI_SIGN, ShowApiUtils.signRequest(textMap, appSecret, false));
		} else {
			textMap.put(Constants.SHOWAPI_SIGN, ShowApiUtils.signRequest(textMap, appSecret, true));
		}
		return null;
	}
	
	public String post()   {
		String res="";
		try {
			String signResult=addSign();
			if(signResult!=null)return signResult;
			res= WebUtils.doPost(url, textMap, uploadMap,headMap, connectTimeout, readTimeout ,charset );
		} catch (Exception e) {
			e.printStackTrace();
			res="{showapi_res_code:-1,showapi_res_error:"+e.toString()+"}";
		}
		return res;
	}
	
	public byte[] postAsByte()   {
		byte res[]=null;
		try {
			String signResult=addSign();
			if(signResult!=null)return signResult.getBytes("utf-8");
			res= WebUtils.doPostAsByte(url, textMap, uploadMap,headMap, connectTimeout, readTimeout ,charset );
		} catch (Exception e) {
			e.printStackTrace();
			try {
				res=("{showapi_res_code:-1,showapi_res_error:"+e.toString()+"}").getBytes("utf-8");
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
		}
		return res;
	}
	
	
	public String get()   {
		String res="";
		try {
			String signResult=addSign();
			if(signResult!=null)return signResult;
			res= WebUtils.doGet(url, textMap ,headMap, connectTimeout, readTimeout ,charset );
		} catch (Exception e) {
			e.printStackTrace();
			res="{showapi_res_code:-1,showapi_res_error:"+e.toString()+"}";
		}
		return res;
	}
	
	public byte[] getAsByte()   {
		byte[]  res=null;
		try {
			String signResult=addSign();
			if(signResult!=null)return signResult.getBytes("utf-8");
			res=WebUtils.doGetAsByte(url, textMap ,headMap, connectTimeout, readTimeout ,charset );
		} catch (Exception e) {
			e.printStackTrace();
			try {
				res=("{showapi_res_code:-1,showapi_res_error:"+e.toString()+"}").getBytes("utf-8");
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
		}
		return res;
	}
	
	private   String errorMsg(String msg){
		String str="{"+Constants.SHOWAPI_RES_CODE+":-1,"+Constants.SHOWAPI_RES_ERROR+":"+msg+","+Constants.SHOWAPI_RES_BODY+":{}}";
		return str;
	}
	
 
	
	public static void main(String adfas[]) throws  Exception{ 
//		String res=new ShowApiRequest("http://route.showapi.com/69-13", "3", "43d67552d6614a6a9637360b4170fdf4")
//		.addTextPara("type","1")
//		.addTextPara("money","100")
//		.post();
//		System.out.println(res);
		
		
//		String res=new ShowApiRequest("http://route.showapi.com/70-17", "3", "43d67552d6614a6a9637360b4170fdf4")
//		.addTextPara("phone","18908712871")
//	          .addTextPara("flowCount","5")
//	               .addTextPara("flowCount.dd","5")
//		.post();
//		System.out.println(res);
		
		
		String res=new ShowApiRequest("http://route.showapi.com/26-4", "3", "43d67552d6614a6a9637360b4170fdf4")
	            .addTextPara("textproducer_char_string","")
	            .addTextPara("jsoncallback","ttt")
	            .post();
		System.out.println(res);
		
//		String res=new ShowApiRequest("http://www.abc.com:803/fileRoute/run/99-38","3","43d67552d6614a6a9637360b4170fdf4")
//	           .addTextPara("content","你好")
//	           .post();
//		System.out.println(res);
		
//		 String res=new ShowApiRequest("http://route.showapi.com/5-1", "72", "78cb2f5a81af499da8a56e140e4bc880")
//                 .addTextPara("carNum", "云A338ct")
//                 .addTextPara("vin", "043256")
//                 .addTextPara("engineNum", "870638")
//                 .post();
//		 System.out.println(res);
		
//		String res=new ShowApiRequest("http://www.abc.com:803/fileRoute/run/56-4", "3", "43d67552d6614a6a9637360b4170fdf4")
//		.addTextPara("orderCode","1122345")
//		.addTextPara("phone","13700645500")
//		.addTextPara("money","5")
//		.post();
//		System.out.println(res);
		
//		String res=new ShowApiRequest("http://www.abc.com:803/fileRoute/run/1-2", "3", "43d67552d6614a6a9637360b4170fdf4")
//		.addFilePara("src_img",new File("c:/a.jpg"))
//		.addFilePara("logo_img",new File("c:/logo.jpg"))
//		.addTextPara("width","333")
//		.addTextPara("height","333")
//		.post();
//		System.out.println(res);
		
		
		
//		String res=new ShowApiRequest("http://www.abc.com:803/fileRoute/run/1-2", "3", "43d67552d6614a6a9637360b4170fdf4")
//		.addFilePara("src_img",new File("c:/a.jpg"))
//		.addFilePara("logo_img",new File("c:/logo.jpg"))
//		.addTextPara("xy","+10+10")
//		.post();
//		System.out.println(res);
//		
		
//		String res=new ShowApiRequest("http://www.abc.com:803/fileRoute/run/28-1","3","43d67552d6614a6a9637360b4170fdf4" )
//	           .addTextPara("mobile","13700645500")
//	           .addTextPara("content","asdfasdfasdfasdfdfs")
//	           .addTextPara("title","秀派科技")
//	           .addTextPara("tNum","秀派科技")
//	           .addTextPara("sendTime","2010-10-24 09:08:10")
//	           .addTextPara("orderCode","12345")
//	           .post();
//		System.out.println(res);
		
		
//		String res=new ShowApiRequest("http://route.showapi.com/69-12","3","43d67552d6614a6a9637360b4170fdf4")
//	           .addTextPara("money","1")
//	           .addTextPara("card","1000115300005565515")
//	           .addTextPara("notifyPhone","13700645500")
//	           .addTextPara("type","1")
//	           .post();
//		System.out.println(res);
		
//		String res=new ShowApiRequest("http://route.showapi.com/28-3","3","43d67552d6614a6a9637360b4170fdf4" )
//	           .addTextPara("userId","13700645500")
//	           .addTextPara("content","http://route.showapi.com/28-1http://route.showapi.com/28-1")
//	           .addTextPara("title","秀派科技")
//	           .addTextPara("sendTime","2010-10-24 09:08:10")
//	           .addTextPara("orderCode","12345")
//	           .post();
//		System.out.println(res);
	}
	
	
}

