package com.show.api.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.show.api.ShowApiRequest;

public class ShowapiTest {
	@Test
	public void ip() {
		String res=new ShowApiRequest("http://route.showapi.com/20-1", "3", "006513e01bd344fca03610d1fd0145f0")
		.addTextPara("ip","221.1.1.2")
		.post();
		System.out.println(res);
	}
	
	@Test
	public void test() {
		String res=new ShowApiRequest("http://route.showapi.com/27-5", "3", "006513e01bd344fca03610d1fd0145f0")
		 .addTextPara("type","xml2json")
	         .addTextPara("xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?>rn<o><age type=\"number\">12</age><list class=\"array\"><e type=\"number\">1</e><e type=\"number\">2</e><e type=\"number\">3</e></list><name type=\"string\">张三</name></o> ")
		.post();
		System.out.println(res);
	}

}
